﻿namespace GiftOfGivers_WebApp1.Controllers
{
    using GiftOfGivers_WebApp1.Models;
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;

    public class VolunteersController : Controller
    {
        private static List<Volunteer> _volunteers = new List<Volunteer>();

        // GET: Volunteers
        public IActionResult Index()
        {
            return View(_volunteers);
        }

        // GET: Volunteers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Volunteers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Volunteer volunteer)
        {
            if (ModelState.IsValid)
            {
                _volunteers.Add(volunteer);
                return RedirectToAction(nameof(Index));
            }
            return View(volunteer);
        }
    }

}
