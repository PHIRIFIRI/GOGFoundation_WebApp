﻿namespace GiftOfGivers_WebApp1.Controllers
{
    using GiftOfGivers_WebApp1.Models;
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;

    public class DonationsController : Controller
    {
        private static List<Donation> _donations = new List<Donation>();

        // GET: Donations
        public IActionResult Index()
        {
            return View(_donations);
        }

        // GET: Donations/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Donations/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Donation donation)
        {
            if (ModelState.IsValid)
            {
                _donations.Add(donation);
                return RedirectToAction(nameof(Index));
            }
            return View(donation);
        }
    }

}
